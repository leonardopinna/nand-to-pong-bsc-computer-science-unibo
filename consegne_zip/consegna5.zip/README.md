Run

```
make
```

to build the 'assembler' executable.

Run

```
./assembler <target_file.asm>
```

to create a new file called 'output.hack' which contains the binary hack code.
